# discord-ifttt

Public version of [discord-ifttt](https://discord-ifttt.vercel.app).

Click the button below or fork the project and deploy it through the [Vercel](https://vercel.com) dashboard.

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/git/external?repository-url=https%3A%2F%2Fgithub.com%2FBirdie0%2Fdiscord-ifttt&project-name=discord-ifttt-selfhosted&repository-name=discord-ifttt)
